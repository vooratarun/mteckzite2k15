﻿<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">

<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
<link rel="shortcut icon" type="image/x-icon" href="gani.ico"/>
<meta http-equiv="Content-Type" content="application/vnd.wap.php+xml; charset=UTF-8"/>
<title>Teckzite 2k15</title>
</head>

<body>




<div class="header"><img src="images/logo.png" alt="" height="50px"/> 
<img src="images/rgukt.png" height="25px;" style="margin-top:0px;margin-left:65%;"/>
</div>





<div class="teg">
<img src="images/v.png" class="vt" alt=""/>
<span class="but"><a href="index.php">Home</a></span>
&nbsp;<font color="white">/</font>
<span class="but"><a href="registration.php">Registration</a></span>

</div>




<div class="new">


<center>
 Teckzite 2K15 starts From<br/>
29-3-2015 and 30-3-2015<br/>
</center>




</div>






<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Registration




</div>





<div class="vib">
<center><font style="color:black;font-size:20px;font-family:veradana;">&nbsp;&nbsp;&nbsp;Registration Form</font></center>
<form id="registration" style="color:black;margin-left:150px;"> 
    			<p class="contact"><label for="name">First Name</label></p> 
    			<input id="fname"  placeholder="First Name" required  type="text"> 
    			 
    			<p class="contact"><label for="name">Last Name</label></p> 
    			<input id="lname"  placeholder="Last Name" required type="text"> 
                
                
        
  
            <p class="contact"><label for="phone">Mobile No</label></p> 
            <input id="phone" name="phone" placeholder="phone number" required type="text"> <br>
            
            
            <p class="contact"><label for="email">Email</label></p> 
            <input id="email" placeholder="Email Address" onblur="mailcheck(this.value)" required type="email"> <br>
            
               <p class="contact"><label for="gender">Gender</label></p>
             <input type="radio" name="gender" value="M" id="gender"> Male &nbsp;&nbsp;&nbsp;
             <input type="radio" name="gender" value="F"> Female
             <br><br>
            
            
               <p class="contact"><label for="department">Department</label></p>
  
            <select class="select-style gender" id="department">
            <option value="">Select</option>
            <option value="CSE">CSE</option>
            <option value="ECE">ECE</option>
            <option value="CE">CIVIL</option>
            <option value="MECH">MECHANICAL</option>
            <option value="CHE">CHEMICAL</option>
            <option value="MME">METTULARGY</option>
            </select><br><br>
            
                <p class="contact"><label for="year">Year</label></p>
  
            <select class="select-style gender" id="year">
            <option value="">Select</option>
            <option value="E1">ENGG1</option>
            <option value="E2">ENGG2</option>
            <option value="E3">ENGG3</option>
            <option value="E4">ENGG4</option>
            </select><br><br>
            
            
            <p class="contact"><label for="college">College</label></p> 
            <input id="college" placeholder="College Name" required type="text"> <br>
            
            
            <p class="contact"><label for="password">Password</label></p> 
            <input id="passwd" placeholder="Password" required type="password"> <br>
            
                <p class="contact"><label for="password">Confirm Password</label></p> 
            <input id="cnfrmpasswd" placeholder="Confirm Password" required type="password"> <br>
            
             <p class="contact"><label for="accomodation">Do you want Accomodation?</label></p>
             <input type="radio" name="accomodation" value="yes" onchange="calfees('yes')"> Yes &nbsp;&nbsp;&nbsp;
             <input type="radio" name="accomodation" value="no" onchange="calfees('no')"> No
             <br><br>
             <span class="successinfo" id="shwamount" style="display:none;">
             <input type="checkbox" name="agree" value="yes"> I agree to pay <b><span id="amount" style="color:green;"></span></b> for the Participation of Teckzite2K15
             </span>
    <input type="submit" style="border:1px;border-radius:10px;height:23px;background-color:#4D7198;color:white;"> <br>
        <br>	 
   </form> 

</div>





<div class="vib">


</div>


<div class="vib2">


</div>


<div class="vib">


</div>


<div class="vib2">


</div>




<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Follow Us On




</div>





<div class="tegt">
 <center>
<a href="https://www.facebook.com/teckzite" target="_blank"><img src="images/facebook.png" class="vt" alt="" height="30px" style="background:trasperant;"/> </a>
  <a href="https://twitter.com/teckzite2k15" target="_blank">  <img src="images/twitter.png" class="vt" alt="" height="30px"/>  </a> 
    <a href="#" target="_blank">  <img src="images/g+.png" class="vt" alt="" height="30px"/>  </a> <br/>
</center>
<img src="images/rekl.png" class="vt" alt=""/><a href="http://www.teckzite.in"> Full Site </a>   <br/> 

</div>









<div class="or">


<img src="images/or.png" class="vt" alt=""/> SDCAC WebTeam 


</div>






</body>

</html>
