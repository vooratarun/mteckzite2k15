﻿<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">

<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
<link rel="shortcut icon" type="image/x-icon" href="gani.ico"/>
<meta http-equiv="Content-Type" content="application/vnd.wap.php+xml; charset=UTF-8"/>
<title>Teckzite 2k15</title>
</head>

<body>




<div class="header"><img src="images/logo.png" alt="" height="50px"/> 
<img src="images/rgukt.png" height="25px;" style="margin-top:0px;margin-left:65%;"/>
</div>





<div class="teg">
<img src="images/v.png" class="vt" alt=""/>
<span class="but"><a href="index.php">Home</a></span>

&nbsp;<font color="white">/</font>
<span class="but"><a href="login.php">Login</a></span>

</div>




<div class="new">


<center>
 Teckzite 2K15 starts From<br/>
29-3-2015 and 30-3-2015<br/>
</center>




</div>






<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Login




</div>





<div class="vib">
<form method=post action=login.php>
<center><font style="color:black;font-size:20px;font-family:veradana;">&nbsp;&nbsp;&nbsp;Login Form</font>
<table>
<tr>
	<td style="color:black;">UserName</td><td><input type="text" placeholder="username" name="uname"></td>
</tr>
<tr>
	<td style="color:black;">Password</td><td><input type="password" placeholder="password" name="pwd"></td>
</tr>
<tr>
	<td colspan=2><center>&nbsp;<input type="submit" name="sub" value="Login" style="border:1px;border-radius:10px;height:23px;background-color:#4D7198;color:white;">&nbsp;<input style="border:1px;border-radius:10px;height:23px;background-color:#4D7198;color:white;" type="reset" value="Reset"></td>
</tr>
</table>
</form>
</center>
</div>





<div class="vib">


</div>


<div class="vib2">


</div>


<div class="vib">


</div>


<div class="vib2">


</div>




<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Follow Us On




</div>





<div class="tegt">
 <center>
<a href="https://www.facebook.com/teckzite" target="_blank"><img src="images/facebook.png" class="vt" alt="" height="30px" style="background:trasperant;"/> </a>
  <a href="https://twitter.com/teckzite2k15" target="_blank">  <img src="images/twitter.png" class="vt" alt="" height="30px"/>  </a> 
    <a href="#" target="_blank">  <img src="images/g+.png" class="vt" alt="" height="30px"/>  </a> <br/>
</center>
<img src="images/rekl.png" class="vt" alt=""/><a href="http://www.teckzite.in"> Full Site </a>   <br/> 

</div>



<?php
if(isset($_POST['sub']))
{
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];

}
?>





<div class="or">


<img src="images/or.png" class="vt" alt=""/> SDCAC WebTeam 


</div>






</body>

</html>
