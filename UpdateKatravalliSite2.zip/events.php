<?php
session_start();
?>
<head>

<link rel="stylesheet" type="text/css" href="style.css"/>
<script href="mteckzite.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="gani.ico"/>
<meta http-equiv="Content-Type" content="application/vnd.wap.php+xml; charset=UTF-8"/>
<title>Teckzite 2k15</title>

<script>
function load_eve(key)
{	
window.location.href=key+".php";
}
</script>
</head>

<body>




<div class="header"><img src="images/logo.png" alt="" height="50px"/> 
<img src="images/rgukt.png" height="25px;" style="margin-top:0px;margin-left:65%;"/>
</div>





<div class="teg">
<img src="images/v.png" class="vt" alt=""/>
<span class="but"><a href="index.php">Home</a></span>
&nbsp;<font color="white">/</font>
<span class="but"><a href="events.php">Events</a></span>
<?php
if(isset($_SESSION['mobileuser']))
	echo "<a href='logout.php' '><span class='but' style='margin-left:20%;color:white;'> Logout<font style='color:white;'> <b>".$_SESSION['mobileuser']."</font></b></a></span>";
else
	{
?>
<span class="but" style='margin-left:20%;color:white;'><a href="login.php">Login</a></span>
<?php } ?>
</div>




<div class="new">


<center>
 Teckzite 2K15 starts From<br/>
29-3-2015 and 30-3-2015<br/>
</center>




</div>






<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Events




</div>





<div class="vib">
<br/>
<div id="eid">	
<center>
<h3>Events</h3>
<table border="0" cellspacing="5px;">
<tr>
<td>

<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:#00388F;color:white;cursor:pointer;"  onclick="load_eve('chem')">
<font style="padding:10px;font-size:10px;"><br />&nbsp;&nbsp;CHEM</font>
</div>

</td>
<td>

<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:#EA1217;color:white;cursor:pointer;" onclick="load_eve('civil')">
<font style="padding:12px;font-size:10px;"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CE</font>
</div>
</td>
<td>

<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:#970DEF;color:white;cursor:pointer;" onclick="load_eve('cse')">
<font style="padding:12px;font-size:10px;"><br />&nbsp;&nbsp;&nbsp;&nbsp;CSE</font>
</div>

</td>
<td>

<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:#ED8F08;color:white;cursor:pointer;" onclick="load_eve('ece')">
<font style="padding:12px;font-size:10px;"><br />&nbsp;&nbsp;&nbsp;&nbsp;ECE</font>
</div>

</td>
</tr>

<tr>
<td>
<a href="me.php">
<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:#339429;color:white;cursor:pointer;" onclick="load_eve('me')">
<font style="padding:12px;font-size:10px;"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ME</font>
</div>
</a>
</td>
<td>
<a href="mme.php">
<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:maroon;color:white;cursor:pointer;" onclick="load_eve('mme')">
<font style="padding:12px;font-size:10px;"><br />&nbsp;&nbsp;&nbsp;&nbsp;MME</font>
</div>
</a>
</td>
<td>
<a href="open.php">
<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:purple;color:white;cursor:pointer;" onclick="load_eve('open')">
<font style="padding:12px;font-size:10px;"><br />&nbsp;&nbsp;&nbsp;&nbsp;Open</font>
</div>
</a>
</td>
<td>
<a href="robo.php">
<div style="width:50px;height:50px;border:1px solid;border-radius:100px;background-color:#C10C60;color:white;cursor:pointer;" onclick="load_eve('robo')">
<font style="padding:12px;font-size:10px;"><br />&nbsp;&nbsp;Robotics</font>
</div>
</a>
</td>
</tr>


</table>
<br/>
<br/>

</center>
</div>

</div>





<div class="vib">


</div>


<div class="vib2">


</div>


<div class="vib">


</div>


<div class="vib2">


</div>




<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Follow Us On




</div>





<div class="tegt">
 <center>
<a href="https://www.facebook.com/teckzite" target="_blank"><img src="images/facebook.png" class="vt" alt="" height="30px" style="background:trasperant;"/> </a>
  <a href="https://twitter.com/teckzite2k15" target="_blank">  <img src="images/twitter.png" class="vt" alt="" height="30px"/>  </a> 
    <a href="#" target="_blank">  <img src="images/g+.png" class="vt" alt="" height="30px"/>  </a> <br/>
</center>
<img src="images/rekl.png" class="vt" alt=""/><a href="http://www.teckzite.in"> Full Site </a>   <br/> 

</div>









<div class="or">



<img src="images/or.png" class="vt" alt=""/> <a href="webteam.php" style="color:white;">SDCAC WebTeam</a> 


</div>






</body>

</html>
