﻿
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">

<head>
<script href="jq.js"></script>
<link rel="stylesheet" type="text/css" href="style.css"/>
<script href="mteckzite.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="gani.ico"/>
<meta http-equiv="Content-Type" content="application/vnd.wap.php+xml; charset=UTF-8"/>
<title>Teckzite 2k15</title>


</head>

<body>

<div id="google">


<div class="header"><img src="images/logo.png" alt="" height="50px"/> 
<img src="images/rgukt.png" height="25px;" style="margin-top:0px;margin-left:65%;"/>
</div>





<div class="teg">
<img src="images/v.png" class="vt" alt=""/>
<span class="but"><a href="index.php">Home</a></span>
&nbsp;<font color="white">/</font>
<span class="but"><a href="webteam.php">Webteam</a></span>

</div>




<div class="new">


<center>
 Teckzite 2K15 starts From<br/>
29-3-2015 and 30-3-2015<br/>
</center>




</div>






<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Home&nbsp;/ Webteam




</div>





<div class="vib">





<?php
include "connect.php";
?>
<center>
</center>
<table border="0" cellspacing="5px;" cellpadding="35px" style="margin-left:10px;">
<tr>
<td>

	<div style="width:50px;height:50px;border:1px solid;border-radius:100px;color:white;cursor:pointer;"  >
	
<img src="webteam/gani.jpg" style="width:50px;height:50px;border-radius:100px">

<FONT COLOR="BLACK" STYLE="FONT-SIZE:10px;padding-top:20px;">K.GANESH</FONT>


</div>

</td>

<td>
<div style="width:50px;height:50px;border:1px solid;border-radius:100px;color:white;cursor:pointer;"  >
	
<img src="webteam/gani.jpg" style="width:50px;height:50px;border-radius:100px">
<FONT COLOR="BLACK" STYLE="FONT-SIZE:10px;padding-top:20px;">K.GANESH</FONT>

</div>
</td>
<td>
<div style="width:50px;height:50px;border:1px solid;border-radius:100px;color:white;cursor:pointer;"  >
	
<img src="webteam/gani.jpg" style="width:50px;height:50px;border-radius:100px">
<FONT COLOR="BLACK" STYLE="FONT-SIZE:10px;padding-top:20px;">K.GANESH</FONT>


</div>
</td>
</tr>
<tr>
<td>
<div style="width:50px;height:50px;border:1px solid;border-radius:100px;color:white;cursor:pointer;"  >
	
<img src="webteam/gani.jpg" style="width:50px;height:50px;border-radius:100px">
<FONT COLOR="BLACK" STYLE="FONT-SIZE:10px;padding-top:20px;">K.GANESH</FONT>

</td>
</tr>
</table>



<br/>
<br/>


</div>

</div>





<div class="vib">


</div>


<div class="vib2">


</div>


<div class="vib">


</div>


<div class="vib2">


</div>




<div class="ot4">


<img src="images/tr.png" class="vt" alt=""/> Follow Us On




</div>





<div class="tegt">
 <center>
<a href="https://www.facebook.com/teckzite" target="_blank"><img src="images/facebook.png" class="vt" alt="" height="30px" style="background:trasperant;"/> </a>
  <a href="https://twitter.com/teckzite2k15" target="_blank">  <img src="images/twitter.png" class="vt" alt="" height="30px"/>  </a> 
    <a href="#" target="_blank">  <img src="images/g+.png" class="vt" alt="" height="30px"/>  </a> <br/>
</center>
<img src="images/rekl.png" class="vt" alt=""/><a href="http://www.teckzite.in"> Full Site </a>   <br/> 

</div>









<div class="or">


<img src="images/or.png" class="vt" alt=""/> SDCAC WebTeam 


</div>






</body>

</html>
